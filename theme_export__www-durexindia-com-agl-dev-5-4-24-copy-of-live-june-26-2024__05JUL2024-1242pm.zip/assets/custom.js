// List of sentences
var _CONTENT = [
  "Real Feel Condoms",
  "Playthings",
  "Lubes",
  "Real Feel Playkit",
];
var _PART = 0;
var _PART_INDEX = 0;
// Holds the handle returned from setInterval
var _INTERVAL_VAL;
$(document).ready(function(){
// Element that holds the text
var _ELEMENT = document.querySelector("#text");
var _ELEMENT2 = document.querySelector("#text2");
var _ELEMENT3 = document.querySelector("#text3");
  
// Start the typing effect on load
_INTERVAL_VAL = setInterval(Type, 50);
$(".t4s-search-header__input ")
  .focus(function () {
    $(".search-input-ani").hide();
  })
  .blur(function () {
    $(".search-input-ani").show();
    $(".t4s-search-header__input ").val("");
  });
$(".t4s-search-header__input ")
  .focus(function () {
    $(".search-input-ani-nav").hide();
  })
  .blur(function () {
    $(".search-input-ani-nav").show();
    $(".t4s-search-header__input ").val("");
  });
$(document).on("click",".search-input-ani",function(){
  $(".search-input-ani").hide();
});

$(".search-input-ani-nav").click(function () {
  $(".search-input-ani-nav").hide();
});
$(".js_btn_search").click(function () {
  $(".search-input-ani-nav").hide();
});
$(".pre_txt").html("Search For ");

// Implements deleting effect
function Delete() {
  var text = _CONTENT[_PART].substring(0, _PART_INDEX - 1);
  _ELEMENT.innerHTML = text;
  _ELEMENT2.innerHTML = text;
  if(_ELEMENT3) _ELEMENT3.innerHTML = text;
  _PART_INDEX--;
  // If sentence has been deleted then start to display the next sentence
  if (text === "") {
    clearInterval(_INTERVAL_VAL);
    // If last sentence then display the first one, else move to the next
    if (_PART == _CONTENT.length - 1) _PART = 0;
    else _PART++;
    _PART_INDEX = 0;
    // Start to display the next sentence after some time
    setTimeout(function () {
      _INTERVAL_VAL = setInterval(Type, 100);
    }, 200);
  }
}
// Implements typing effect
function Type() {
  var text = _CONTENT[_PART].substring(0, _PART_INDEX + 1);
  if(!_ELEMENT3) {
    $(".pre_txt").html("Search For ");
    _ELEMENT3 = document.querySelector("#text3");
  }
  _ELEMENT.innerHTML = text;
  _ELEMENT2.innerHTML = text;
  if(_ELEMENT3) _ELEMENT3.innerHTML = text;
  _PART_INDEX++;
  // If full sentence has been displayed then start to delete the sentence after some time
  if (text === _CONTENT[_PART]) {
    clearInterval(_INTERVAL_VAL);
    setTimeout(function () {
      _INTERVAL_VAL = setInterval(Delete, 50);
    }, 1000);
  }
}
});

